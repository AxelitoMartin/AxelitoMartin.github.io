library(shiny)
library(ggplot2)

ui <- fluidPage(
  titlePanel("Example app in shiny"),
  
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    
    # Sidebar panel for inputs ----
    sidebarPanel(
      
      # Input: Select the random distribution type ----
      radioButtons("dist", "Distribution type:",
                   c("Normal" = "norm",
                     "Uniform" = "unif",
                     "Log-normal" = "lnorm",
                     "Exponential" = "exp"
                   )),
      
      # br() element to introduce extra vertical spacing ----
      br(),
      
      # Input: Slider for the number of observations to generate ----
      sliderInput("n", "Number of observations:",
                  min = 2, max = 100, value = 10)#,
      
      # submitButton(text = "Submit new inputs")
      
    ),
    
    # Main panel for displaying outputs ----
    mainPanel(
      plotOutput("hist"),
      textOutput("ThatsMe")
    )
    
  )
  
)

server <- function(input, output) {
  
  # generate some random data in a reactive function
  dat <- reactive({
    if(input$dist == "norm") dat <- as.data.frame(matrix(rnorm(as.numeric(input$n)),ncol = 1))
    if(input$dist == "unif") dat <- as.data.frame(matrix(runif(as.numeric(input$n)),ncol = 1))
    if(input$dist == "lnorm") dat <- as.data.frame(matrix(rlnorm(as.numeric(input$n)),ncol = 1))
    if(input$dist == "exp") dat <- as.data.frame(matrix(rexp(as.numeric(input$n)),ncol = 1))
    colnames(dat) <- "Obs"
    
    return(list(dat=dat,other="I was too lazy to come up with something else to do"))
  })
  
  # output plot
  output$hist <- renderPlot({
    ggplot(dat()$dat,aes(Obs)) + geom_histogram()
  })
  
  # I am lazy output
  output$ThatsMe <- renderText({
    dat()$other
  })
}

# Run the application 
shinyApp(ui = ui, server = server)