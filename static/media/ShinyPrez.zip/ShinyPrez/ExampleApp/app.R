library(shiny)
library(shinydashboard)
library(ggplot2)

ui <- dashboardPage(
  dashboardHeader(title = "Stats VS Sloths: The final smackdown",titleWidth = 400),
  
  dashboardSidebar(
    width = 300,
    sidebarMenu(
      menuItem("Stats stuff", tabName = "stats", icon = icon("columns")),
      menuItem("Sloth party", tabName = "sloth", icon = icon("github-alt"))
    )
  ),
  
  dashboardBody(
    tabItems(
      
      ### Stats ###
      tabItem(tabName = "stats",
              sidebarLayout(
                sidebarPanel(
                  width=12,
                  h2("Choose a distribution"),
                  radioButtons("dist", "Distribution type:",
                               c("Normal" = "norm",
                                 "Uniform" = "unif",
                                 "Log-normal" = "lnorm",
                                 "Exponential" = "exp"
                               )),
                  sliderInput("n", "Number of observations:",
                              min = 2, max = 100, value = 10)
                ),
                mainPanel(
                  width = 12,
                  plotOutput("hist")
                )
              )
      ),
      
      
      #SLOTHS
      tabItem(tabName = "sloth",
              sidebarLayout(
                sidebarPanel(
                  width=12,
                  h2("Choose a sloth:"),
                  radioButtons("sloth.type", "Good decision, as a reward choose a sloth:",
                               c("Napping sloth" = "nap",
                                 "Active sloth"="active"
                               ))
                ),
                mainPanel(
                  width = 12,
                  imageOutput("sloth")
                )
              )
      )
      
      
    )
  )
)




server <- function(input, output) {
  
  # generate some random data in a reactive function
  dat <- reactive({
    if(input$dist == "norm") dat <- as.data.frame(matrix(rnorm(as.numeric(input$n)),ncol = 1))
    if(input$dist == "unif") dat <- as.data.frame(matrix(runif(as.numeric(input$n)),ncol = 1))
    if(input$dist == "lnorm") dat <- as.data.frame(matrix(rlnorm(as.numeric(input$n)),ncol = 1))
    if(input$dist == "exp") dat <- as.data.frame(matrix(rexp(as.numeric(input$n)),ncol = 1))
    colnames(dat) <- "Obs"
    
    return(list(dat=dat,other="I was too lazy to come up with something else to do"))
  })
  
  # output plot
  output$hist <- renderPlot({
    ggplot(dat()$dat,aes(Obs)) + geom_histogram()
  })
  
  # I am lazy output
  output$ThatsMe <- renderText({
    dat()$other
  })
  
  #### my best potrait
  output$sloth <- renderImage({
    if(input$sloth.type == "nap"){
      # When input$n is 1, filename is ./images/image1.jpeg
      filename <- normalizePath(file.path("Sloth.png"))}
    
    if(input$sloth.type == "active"){
      # When input$n is 1, filename is ./images/image1.jpeg
      filename <- normalizePath(file.path("Sloth_active.png"))}
    
    # Return a list containing the filename
    list(src = filename,
         width = 600,
         height = 500)
  }, deleteFile = FALSE)
  
}

# Run the application 
shinyApp(ui = ui, server = server)